from cowpy import cow

print(cow.milk_random_cow("Hello, Dev07!"))
